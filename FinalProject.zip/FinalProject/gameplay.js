let x = 0; 
let xInv = 0;
let currentImage = 0; 
let lastCycleTime = 0; 
let isFlipped = false; 
let imageWidth; 